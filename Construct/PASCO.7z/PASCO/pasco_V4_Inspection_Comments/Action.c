// PASCO_V4_Inspection_Comments

Action()
{
    
	
	
	lr_start_transaction("Authentication_PASCO");
			
		web_set_max_html_param_len("58700");

		web_set_sockets_option("SSL_VERSION","TLS");
		
		web_set_sockets_option("IGNORE_PREMATURE_SHUTDOWN", "1");

		web_reg_save_param("Token",
			"LB=,\"result\":\"",
			"RB=\"",
			"Search=All",
			LAST);
		
		 web_add_header("Accept-Encoding",				"gzip,deflate");


		 web_add_header("Connection",				"Keep-Alive");


		 web_add_header("User-Agent",				"Apache-HttpClient/4.1.1 (java 1.5)");


		 web_reg_find("Search=Body",		"Text=200",		LAST);

		status=web_custom_request("web_custom_request",
			"URL={BizURL}/apis/v4/auth/agency",
			"Method=POST",
			"Resource=0",
			"Referer=",
			"Body={\"agency\": \"PASCO\",\"userId\": \"admin\",\"password\": \"admin\"}",
			LAST);

		if(status==LR_PASS)
		{
			lr_output_message("Message: Get token successful!");
		}


		else
		{
			lr_error_message("Message: Can't get token from server, please check the request !");
			return -1;
		}

		lr_think_time(10);
		
	lr_end_transaction("Authentication_PASCO", LR_PASS);

        web_add_header("AppD_Header", "PASCO_V4_Inspection_Comments");
    

lr_start_transaction("PASCO_V4_Inspection_Comments");


    web_add_header("Accept-Encoding",   "gzip,deflate");

    web_add_header("Connection",             "Keep-Alive");
    
    web_add_header("Content-Type","application/json");

    web_add_header("User-Agent","Apache-HttpClient/4.1.1 (java 1.5)");
    
        web_add_header("Authorization",
               "{Token}");


        web_reg_find("Search=Body",    "Text=200",    LAST);

        status=web_custom_request("web_custom_request",
       "URL={BizURL}/apis/v4/inspections/23576864/comments",
       "Method=GET",
       "Resource=0",
       "Referer=",
       "Mode=HTTP",
        LAST);

    if(status==LR_PASS)
    {
        lr_end_transaction("PASCO_V4_Inspection_Comments", LR_PASS);
        lr_output_message("Message: PASCO_V4_Inspection_Comments successful!");
    }
    else
    {
        lr_end_transaction("PASCO_V4_Inspection_Comments", LR_FAIL);
        lr_error_message("Message: Failed to PASCO_V4_Inspection_Comments!");
        return 0;
    }

        
    return 0;
}
